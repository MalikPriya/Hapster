import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile2',
  templateUrl: './profile2.page.html',
  styleUrls: ['./profile2.page.scss'],
})
export class Profile2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
