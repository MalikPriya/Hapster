import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-garagelisting',
  templateUrl: './garagelisting.page.html',
  styleUrls: ['./garagelisting.page.scss'],
})
export class GaragelistingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
