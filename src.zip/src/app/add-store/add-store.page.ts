import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-store',
  templateUrl: './add-store.page.html',
  styleUrls: ['./add-store.page.scss'],
})
export class AddStorePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
