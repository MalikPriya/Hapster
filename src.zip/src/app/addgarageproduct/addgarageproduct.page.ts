import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addgarageproduct',
  templateUrl: './addgarageproduct.page.html',
  styleUrls: ['./addgarageproduct.page.scss'],
})
export class AddgarageproductPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
