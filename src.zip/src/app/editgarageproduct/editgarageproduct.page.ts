import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editgarageproduct',
  templateUrl: './editgarageproduct.page.html',
  styleUrls: ['./editgarageproduct.page.scss'],
})
export class EditgarageproductPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
