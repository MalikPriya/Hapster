export class Customer {

        id?: any;
        customerId?: any;
        street?: string;
        city?: string;
        state?: string;
        pincode?: string;
      }

