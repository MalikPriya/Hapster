import { Component, OnInit } from '@angular/core';
import {AllapiService} from '../commonService/allapi.service';
import { Router, ActivatedRoute } from "@angular/router";
@Component({
  selector: 'app-store-service',
  templateUrl: './store-service.page.html',
  styleUrls: ['./store-service.page.scss'],
})
export class StoreServicePage implements OnInit {
  storedetails:any=[];
  type: string;
  public list:any=[];
  public categoryId : any = '';
  isAddMode : boolean;
  constructor(private _api:AllapiService,private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() :void{
    this.type = 'products';
    this.categoryId = this.route.snapshot.paramMap.get('categoryId') || '';
    this.isAddMode = !this.categoryId;
    console.log('88888',this.isAddMode);

  

  }

  segmentChanged(ev: any) {
    console.log('Segment changed', ev);
  }

  storeList(id:any){

    this._api.storelistbycategory(id).subscribe(
      res =>{
        console.log(123,res);
        if(res.error==false){
          this.storedetails= res.data;
        }else{
          this.storedetails={};
        }

      },err =>{

      }
    )
  }


}
