import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-service',
  templateUrl: './profile-service.page.html',
  styleUrls: ['./profile-service.page.scss'],
})
export class ProfileServicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
