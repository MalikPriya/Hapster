import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-garagelanding',
  templateUrl: './garagelanding.page.html',
  styleUrls: ['./garagelanding.page.scss'],
})
export class GaragelandingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
