import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bargain',
  templateUrl: './bargain.page.html',
  styleUrls: ['./bargain.page.scss'],
})
export class BargainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
