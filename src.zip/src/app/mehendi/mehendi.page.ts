import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mehendi',
  templateUrl: './mehendi.page.html',
  styleUrls: ['./mehendi.page.scss'],
})
export class MehendiPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  
}
