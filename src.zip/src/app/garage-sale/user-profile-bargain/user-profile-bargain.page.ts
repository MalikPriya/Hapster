import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-profile-bargain',
  templateUrl: './user-profile-bargain.page.html',
  styleUrls: ['./user-profile-bargain.page.scss'],
})
export class UserProfileBargainPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
