import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-profile3',
  templateUrl: './user-profile3.page.html',
  styleUrls: ['./user-profile3.page.scss'],
})
export class UserProfile3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
