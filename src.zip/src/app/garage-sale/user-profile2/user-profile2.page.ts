import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-profile2',
  templateUrl: './user-profile2.page.html',
  styleUrls: ['./user-profile2.page.scss'],
})
export class UserProfile2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
